pdflatex paper && bibtex paper && pdflatex paper && pdflatex paper
